package br.usjt.previsaotempo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppPrevisoesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppPrevisoesApplication.class, args);
	}

}
