package br.usjt.previsaotempo.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import br.usjt.previsaotempo.model.Cidade;

public interface CidadesRepository extends JpaRepository<Cidade, Long> {

}