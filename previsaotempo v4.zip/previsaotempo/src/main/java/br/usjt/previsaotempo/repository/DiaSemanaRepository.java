package br.usjt.previsaotempo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import br.usjt.previsaotempo.model.DiaSemana;

public interface DiaSemanaRepository extends JpaRepository<DiaSemana, Long> {

}