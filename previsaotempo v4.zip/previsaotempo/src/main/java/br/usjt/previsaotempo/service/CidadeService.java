package br.usjt.previsaotempo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.usjt.previsaotempo.model.Cidade;
import br.usjt.previsaotempo.repository.CidadesRepository;

@Service
public class CidadeService {
	@Autowired
	private CidadesRepository cidadesRepo;

	public void salvar(Cidade cidade) {
		cidadesRepo.save(cidade);
	}

	public List<Cidade> listarTodos(){
		return cidadesRepo.findAll();
	}
}