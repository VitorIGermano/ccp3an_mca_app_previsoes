package br.usjt.previsaotempo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import br.usjt.previsaotempo.model.DiaSemana;
import br.usjt.previsaotempo.repository.DiaSemanaRepository;

@Service
public class DiaSemanaService {
	@Autowired
	private DiaSemanaRepository diasRepo;

	public List<DiaSemana> listarTodos(){
		return diasRepo.findAll();
	}
}