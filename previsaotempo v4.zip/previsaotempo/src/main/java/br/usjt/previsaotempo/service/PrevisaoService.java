package br.usjt.previsaotempo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import br.usjt.previsaotempo.repository.*;
import br.usjt.previsaotempo.model.Previsao;

@Service
public class PrevisaoService {
	@Autowired
	private PrevisoesRepository previsoesRepo;
	
	public void salvar(Previsao previsao) {
		previsoesRepo.save(previsao);
	}
	
	public List<Previsao> listarTodos(){
		List<Previsao> previsoes = previsoesRepo.findAll();
		
		return previsoes;
	}

}



