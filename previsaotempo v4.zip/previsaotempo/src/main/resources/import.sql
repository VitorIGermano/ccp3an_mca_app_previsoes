insert into Dias_Semana(id, diaSemana) values (1, 'Domingo');
insert into Dias_Semana(id, diaSemana) values (2, 'Segunda-Feira');
insert into Dias_Semana(id, diaSemana) values (3, 'Terça-Feira');
insert into Dias_Semana(id, diaSemana) values (4, 'Quarta-Feira');
insert into Dias_Semana(id, diaSemana) values (5, 'Quinta-Feira');
insert into Dias_Semana(id, diaSemana) values (6, 'Sexta-Feira');
insert into Dias_Semana(id, diaSemana) values (7, 'Sábado');

insert into Cidades(id, nome, latitude, longitude) values (1, 'São Paulo', -23.590510, -46.660463);

insert into Previsoes(id, id_diaSemana, tempMin, tempMax, umidade, descricao, id_cidade, dataHora) values (1, 1, 22.0, 31.9, 57, 'Pancadas de chuva.', -23.590510, -46.660463, 1, CURRENT_TIMESTAMP());
insert into Previsoes(id, id_diaSemana, tempMin, tempMax, umidade, descricao, id_cidade, dataHora) values (2, 2, 21.7, 28.7, 65, 'Sol e aumento de nuvens de manhã.', -23.590510, -46.660463, 1, CURRENT_TIMESTAMP());
insert into Previsoes(id, id_diaSemana, tempMin, tempMax, umidade, descricao, id_cidade, dataHora) values (3, 3, 24.1, 29.0, 64, 'Sol e aumento de nuvens de tarde.', -23.590510, -46.660463, 1, CURRENT_TIMESTAMP());

insert into usuario (id, login, senha) values (1, 'user', '12345678');